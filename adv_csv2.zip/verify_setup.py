#!/usr/bin/env python3
"""
Verify that all dependencies are correctly installed and configured.
"""

import sys

def check_import(module_name, package_name=None):
    """
    Attempt to import a module and report success or failure.
    """
    display_name = package_name or module_name
    try:
        __import__(module_name)
        print(f"✓ {display_name} is installed")
        return True
    except ImportError as e:
        print(f"✗ {display_name} is NOT installed")
        print(f"  Error: {e}")
        return False


def verify_environment():
    """
    Check that all required environment variables are set.
    """
    import os
    
    required_vars = ["JAMF_URL", "JAMF_CLIENT_ID", "JAMF_CLIENT_SECRET"]
    all_set = True
    
    for var in required_vars:
        if os.getenv(var):
            print(f"✓ {var} is set")
        else:
            print(f"✗ {var} is NOT set")
            all_set = False
    
    return all_set


def main():
    """
    Run all verification checks.
    """
    print("Verifying installation...")
    print("=" * 50)
    print()
    
    print("Checking Python packages:")
    results = []
    results.append(check_import("jamfpy", "jamfpy SDK"))
    results.append(check_import("requests"))
    results.append(check_import("importer", "Importer library"))
    
    print()
    print("Checking importer sub-modules:")
    results.append(check_import("importer.resources"))
    results.append(check_import("importer.models"))
    results.append(check_import("importer.hcl"))
    
    print()
    print("Checking environment variables:")
    env_ok = verify_environment()
    
    print()
    print("=" * 50)
    
    if all(results) and env_ok:
        print("✓ All checks passed! You're ready to run the extraction.")
        print()
        print("Run: python extract_advanced_searches.py")
        return 0
    else:
        print("✗ Some checks failed. Please review the errors above.")
        print()
        if not all(results):
            print("To fix package issues:")
            print("  1. Ensure you're in the virtual environment")
            print("  2. Run: uv pip install -r requirements.txt")
        if not env_ok:
            print()
            print("To fix environment variable issues:")
            print("  1. Copy .env.example to .env")
            print("  2. Edit .env with your Jamf Pro credentials")
            print("  3. Run: source .env  (or export variables manually)")
        return 1


if __name__ == "__main__":
    sys.exit(main())
