# Installation Summary

## What You Have

This project extracts Advanced Computer Searches from Jamf Pro and generates Terraform import blocks.

**Complete project structure:**

```
advanced-computer-search-extractor/
├── extract_advanced_searches.py  # Main script
├── verify_setup.py               # Installation checker
├── setup.sh                      # Automated setup
├── requirements.txt              # Dependencies
├── .env.example                  # Credentials template
├── .gitignore                    # Git ignore rules
├── README.md                     # Main documentation
├── INSTALL.md                    # Detailed install guide
├── QUICKREF.md                   # Quick reference
└── importer/                     # Local library (10 files)
    ├── __init__.py
    ├── importer.py
    ├── resources.py
    ├── models.py
    ├── hcl.py
    ├── enums.py
    ├── dataclasses.py
    ├── constants.py
    ├── config_ingest.py
    └── exceptions.py
```

## Two Installation Methods

### Method 1: Automated (Recommended)

```bash
# Run the setup script
bash setup.sh

# Configure credentials
cp .env.example .env
# Edit .env with your Jamf Pro details

# Verify installation
source .venv/bin/activate
python verify_setup.py

# Run extraction
python extract_advanced_searches.py
```

### Method 2: Manual

```bash
# Install uv if needed
curl -LsSf https://astral.sh/uv/install.sh | sh

# Create virtual environment
uv venv

# Activate it
source .venv/bin/activate

# Install dependencies (including jamfpy from GitHub)
uv pip install -r requirements.txt

# Configure credentials
cp .env.example .env
# Edit .env with your details

# Verify
python verify_setup.py

# Run
python extract_advanced_searches.py
```

## How the Dependencies Work

### 1. jamfpy SDK (from GitHub)

The `requirements.txt` file contains:
```
jamfpy @ git+https://github.com/thejoeker12/jamfpy-python-sdk-jamfpro.git@main
```

This tells `uv pip` to:
- Clone the repository from GitHub
- Install it directly into your virtual environment
- No manual cloning needed

### 2. importer library (local)

The `importer/` directory is already included in your project:
- No installation required
- Python imports it directly from the local directory
- Contains all the logic for generating Terraform import blocks

### 3. requests (standard package)

Installed normally from PyPI as a dependency.

## What Happens When You Run setup.sh

1. Checks for `uv` and `git` (required)
2. Creates virtual environment in `.venv/`
3. Installs jamfpy from GitHub
4. Installs requests from PyPI
5. Verifies importer library is present
6. Reports success/failure

## Environment Configuration

The `.env` file needs three variables:

```bash
JAMF_URL=https://your-tenant.jamfcloud.com
JAMF_CLIENT_ID=abc123...
JAMF_CLIENT_SECRET=xyz789...
```

Get these from your Jamf Pro API credentials section.

## Running the Extractor

Once installed and configured:

```bash
# Activate the virtual environment (if not already active)
source .venv/bin/activate

# Run the extraction
python extract_advanced_searches.py
```

This will:
1. Connect to Jamf Pro using OAuth2
2. Fetch all Advanced Computer Searches
3. Generate import blocks for each search
4. Save to `terraform_imports/advanced_computer_searches.tf`

## Output Example

The generated file will look like:

```hcl
import {
  id = 1
  to = jamfpro_advanced_computer_search.jamfpro_advanced_computer_search_1
}

import {
  id = 2
  to = jamfpro_advanced_computer_search.jamfpro_advanced_computer_search_2
}
```

## Using with Terraform

```bash
cd terraform_imports
terraform init
terraform plan -generate-config-out=generated.tf
```

This generates the complete resource configurations.

## File Reference

| Read This | For |
|-----------|-----|
| **README.md** | Complete documentation and usage |
| **INSTALL.md** | Detailed installation instructions |
| **QUICKREF.md** | Quick command reference |
| **.env.example** | Template for your credentials |

## Quick Troubleshooting

**Check if jamfpy installed correctly:**
```bash
python -c "import jamfpy; print(jamfpy.__file__)"
```

**Check if importer is accessible:**
```bash
python -c "from importer import Importer; print('OK')"
```

**Verify all at once:**
```bash
python verify_setup.py
```

## Key Points

1. **jamfpy installs from GitHub** - no need to clone manually
2. **importer is local** - already in your project directory
3. **Everything runs in .venv** - doesn't affect system Python
4. **OAuth2 only** - uses client credentials, not username/password
5. **Output is HCL** - ready for Terraform import

## Next Steps

1. Run `bash setup.sh`
2. Configure `.env` with your credentials
3. Run `python verify_setup.py` to check everything
4. Run `python extract_advanced_searches.py` to extract
5. Use the generated import blocks in Terraform

## Support

- **jamfpy issues**: https://github.com/thejoeker12/jamfpy-python-sdk-jamfpro
- **Terraform provider**: https://registry.terraform.io/providers/deploymenttheory/jamfpro
- **Jamf Pro API**: https://developer.jamf.com/

That's it! You're ready to go.
