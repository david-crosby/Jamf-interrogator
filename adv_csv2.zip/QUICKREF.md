# Quick Reference

## One-Line Installation

```bash
bash setup.sh && cp .env.example .env
```

Then edit `.env` with your credentials and run:

```bash
source .venv/bin/activate && python extract_advanced_searches.py
```

## Project Layout

```
project/
├── extract_advanced_searches.py  ← Main script
├── verify_setup.py               ← Test installation
├── importer/                     ← Local library (included)
│   ├── __init__.py
│   ├── importer.py              ← Core importer class
│   ├── resources.py             ← Resource definitions
│   └── ...                      ← Supporting modules
├── requirements.txt              ← jamfpy from GitHub + requests
├── .env                          ← Your credentials (create this)
└── .venv/                        ← Virtual environment (auto-created)
```

## How Dependencies Are Installed

1. **jamfpy SDK**: Installed from GitHub
   - Source: `https://github.com/thejoeker12/jamfpy-python-sdk-jamfpro`
   - Method: Direct Git install via `requirements.txt`
   - Command: `uv pip install git+https://github.com/...`

2. **importer library**: Local module
   - Location: `importer/` directory in project
   - Method: Python imports directly from local directory
   - No installation needed (already in project)

3. **requests**: Standard PyPI package
   - Installed as dependency via `requirements.txt`

## Environment Variables

Required variables in `.env`:

```bash
JAMF_URL=https://your-tenant.jamfcloud.com
JAMF_CLIENT_ID=your-oauth-client-id
JAMF_CLIENT_SECRET=your-oauth-client-secret
```

## Common Commands

```bash
# Initial setup
bash setup.sh

# Activate environment
source .venv/bin/activate

# Verify everything works
python verify_setup.py

# Run extraction
python extract_advanced_searches.py

# Update jamfpy SDK
uv pip install --upgrade git+https://github.com/thejoeker12/jamfpy-python-sdk-jamfpro.git@main
```

## File Descriptions

| File | Purpose |
|------|---------|
| `extract_advanced_searches.py` | Main extraction script - connects to Jamf Pro and generates import blocks |
| `verify_setup.py` | Tests that all dependencies are correctly installed |
| `setup.sh` | Automated setup - creates venv and installs everything |
| `requirements.txt` | Python dependencies - points to jamfpy GitHub repo |
| `importer/` | Local library for generating Terraform import blocks |
| `.env.example` | Template for environment variables |
| `README.md` | Full documentation |
| `INSTALL.md` | Detailed installation guide |

## Troubleshooting Quick Fixes

**"Module 'jamfpy' not found"**
```bash
source .venv/bin/activate
uv pip install git+https://github.com/thejoeker12/jamfpy-python-sdk-jamfpro.git@main
```

**"Module 'importer' not found"**
```bash
# Make sure you're in the project root directory
pwd  # Should show your project directory with importer/ folder
```

**"Environment variables not set"**
```bash
cp .env.example .env
# Edit .env, then:
export $(cat .env | xargs)
```

## Output Location

Generated files go to: `terraform_imports/advanced_computer_searches.tf`

## What Gets Installed

- **In .venv/**: jamfpy SDK (from GitHub) + requests
- **In project/**: importer library (already there, no install needed)
- **System-wide**: Nothing (all contained in .venv)
