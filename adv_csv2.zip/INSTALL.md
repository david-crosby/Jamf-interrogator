# Installation Guide

This guide covers installing both the jamfpy SDK from GitHub and setting up the importer library.

## Quick Installation

Run the automated setup script:

```bash
bash setup.sh
```

This will handle everything automatically.

## Manual Installation

If you prefer to install manually, follow these steps:

### 1. Install uv

If you haven't already installed uv:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### 2. Create Virtual Environment

```bash
uv venv
source .venv/bin/activate
```

On Windows:
```bash
.venv\Scripts\activate
```

### 3. Install Dependencies

The jamfpy SDK will be installed directly from GitHub:

```bash
uv pip install -r requirements.txt
```

This installs:
- jamfpy SDK from GitHub (thejoeker12/jamfpy-python-sdk-jamfpro)
- requests library

### 4. Verify Installation

Check that jamfpy is installed correctly:

```bash
python -c "import jamfpy; print(jamfpy.__file__)"
```

Check that the importer library is accessible:

```bash
python -c "from importer import Importer; print('Importer loaded successfully')"
```

## Project Structure

After installation, your project should look like this:

```
.
├── .env.example              # Environment variable template
├── .gitignore                # Git ignore rules
├── README.md                 # Main documentation
├── INSTALL.md                # This file
├── requirements.txt          # Python dependencies
├── setup.sh                  # Automated setup script
├── extract_advanced_searches.py  # Main script
├── importer/                 # Importer library
│   ├── __init__.py
│   ├── config_ingest.py
│   ├── constants.py
│   ├── dataclasses.py
│   ├── enums.py
│   ├── exceptions.py
│   ├── hcl.py
│   ├── importer.py
│   ├── models.py
│   └── resources.py
└── .venv/                    # Virtual environment (created by setup)
```

## Troubleshooting

### Cannot find module 'importer'

Ensure you're running the script from the project root directory where the `importer/` folder exists.

### Git authentication errors

If you encounter authentication issues when installing from GitHub:

1. For public repositories (like jamfpy), no authentication is needed
2. If issues persist, try cloning manually:

```bash
git clone https://github.com/thejoeker12/jamfpy-python-sdk-jamfpro.git
cd jamfpy-python-sdk-jamfpro
uv pip install -e .
```

### SSL Certificate Errors

If you encounter SSL errors:

```bash
uv pip install --trusted-host github.com -r requirements.txt
```

### Missing System Dependencies

On some systems, you may need to install system packages:

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install python3-dev git
```

**macOS:**
```bash
brew install python git
```

## Updating Dependencies

To update the jamfpy SDK to the latest version:

```bash
uv pip install --upgrade git+https://github.com/thejoeker12/jamfpy-python-sdk-jamfpro.git@main
```

## Development Installation

For development purposes, you can install jamfpy in editable mode:

```bash
git clone https://github.com/thejoeker12/jamfpy-python-sdk-jamfpro.git
cd jamfpy-python-sdk-jamfpro
uv pip install -e .
cd ..
```

This allows you to modify the SDK code and see changes immediately.

## Next Steps

After successful installation:

1. Configure your environment variables:
   ```bash
   cp .env.example .env
   # Edit .env with your Jamf Pro credentials
   ```

2. Run the extraction script:
   ```bash
   python extract_advanced_searches.py
   ```

## Support

For issues with:
- **jamfpy SDK**: Visit https://github.com/thejoeker12/jamfpy-python-sdk-jamfpro
- **This project**: Check the main README.md for troubleshooting tips
