#!/usr/bin/env bash
set -e

echo "Setting up Advanced Computer Search Extractor"
echo "=============================================="
echo

if ! command -v uv &> /dev/null; then
    echo "Error: uv is not installed"
    echo "Install uv: curl -LsSf https://astral.sh/uv/install.sh | sh"
    exit 1
fi

if ! command -v git &> /dev/null; then
    echo "Error: git is not installed"
    echo "Git is required to install jamfpy from GitHub"
    exit 1
fi

echo "Creating virtual environment..."
uv venv

echo "Activating virtual environment..."
source .venv/bin/activate

echo "Installing dependencies..."
echo "  - Installing jamfpy from GitHub..."
echo "  - Installing other dependencies..."
uv pip install -r requirements.txt

echo
echo "Verifying installation..."
if python -c "import jamfpy" 2>/dev/null; then
    echo "  ✓ jamfpy SDK installed successfully"
else
    echo "  ✗ jamfpy SDK installation failed"
    exit 1
fi

if python -c "from importer import Importer" 2>/dev/null; then
    echo "  ✓ Importer library found"
else
    echo "  ✗ Importer library not found"
    exit 1
fi

echo
echo "Setup complete!"
echo
echo "Project structure:"
echo "  extract_advanced_searches.py  - Main extraction script"
echo "  importer/                     - Local importer library"
echo "  .venv/                        - Virtual environment"
echo
echo "Next steps:"
echo "  1. Configure credentials:"
echo "       cp .env.example .env"
echo "       # Edit .env with your Jamf Pro details"
echo
echo "  2. Activate the virtual environment:"
echo "       source .venv/bin/activate"
echo
echo "  3. Run the extraction:"
echo "       python extract_advanced_searches.py"
echo
echo "For detailed information, see INSTALL.md"
