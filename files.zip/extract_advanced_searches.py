#!/usr/bin/env python3

import os
import sys
import json
import re
from pathlib import Path

try:
    from jamf_pro_sdk import JamfProClient, BasicAuthProvider
    SDK_AVAILABLE = 'jamf_pro_sdk'
except ImportError:
    SDK_AVAILABLE = None
    print("Warning: jamf-pro-sdk not found")
    print("Attempting to use alternative SDK...")


def sanitise_name(name):
    """
    Convert search name to valid Terraform resource name.
    Removes special characters and converts to snake_case.
    """
    sanitised = name.lower()
    sanitised = re.sub(r'[^\w\s-]', '', sanitised)
    sanitised = re.sub(r'[\s-]+', '_', sanitised)
    sanitised = re.sub(r'_+', '_', sanitised)
    sanitised = sanitised.strip('_')
    
    return sanitised


def generate_import_block(search_id, search_name):
    """Generate Terraform import block for an advanced computer search."""
    resource_name = sanitise_name(search_name)
    
    import_block = f'''import {{
  to = jamfpro_advanced_computer_search.{resource_name}
  id = "{search_id}"
}}
'''
    return import_block


def fetch_advanced_searches_jamf_pro_sdk(jamf_url, username, password):
    """Retrieve searches using the official Jamf Pro SDK."""
    try:
        client = JamfProClient(
            server=jamf_url,
            credentials=BasicAuthProvider(username, password)
        )
        
        searches = client.classic_api.list_advanced_computer_searches()
        
        if isinstance(searches, dict) and 'advanced_computer_searches' in searches:
            return searches['advanced_computer_searches']
        
        return searches if isinstance(searches, list) else []
        
    except Exception as e:
        print(f"Error fetching with jamf-pro-sdk: {e}")
        return None


def fetch_advanced_searches(jamf_url, username, password):
    """Retrieve all advanced computer searches using available SDK."""
    
    if SDK_AVAILABLE == 'jamf_pro_sdk':
        print("Using jamf-pro-sdk...")
        return fetch_advanced_searches_jamf_pro_sdk(jamf_url, username, password)
    else:
        print("Error: No supported Jamf SDK found")
        print("Install with: uv pip install jamf-pro-sdk")
        sys.exit(1)


def write_import_file(import_blocks, output_path):
    """Write all import blocks to a Terraform file."""
    try:
        with open(output_path, 'w') as f:
            f.write("# Terraform import blocks for Jamf Pro advanced computer searches\n")
            f.write("# Generated automatically - review before importing\n\n")
            f.write('\n'.join(import_blocks))
        
        print(f"\nSuccessfully wrote {len(import_blocks)} import blocks to {output_path}")
    except IOError as e:
        print(f"Error writing to file: {e}")
        sys.exit(1)


def write_summary_json(searches, output_path):
    """Write a JSON summary of all searches for reference."""
    try:
        summary = {
            'total_searches': len(searches),
            'searches': [
                {
                    'id': search.get('id'),
                    'name': search.get('name'),
                    'terraform_resource_name': sanitise_name(search.get('name', ''))
                }
                for search in searches
            ]
        }
        
        with open(output_path, 'w') as f:
            json.dump(summary, f, indent=2)
        
        print(f"Summary written to {output_path}")
    except IOError as e:
        print(f"Warning: Could not write summary file: {e}")


def main():
    jamf_url = os.getenv("JAMF_PRO_URL")
    jamf_username = os.getenv("JAMF_PRO_USERNAME")
    jamf_password = os.getenv("JAMF_PRO_PASSWORD")
    
    if not all([jamf_url, jamf_username, jamf_password]):
        print("Error: Required environment variables not set")
        print("Required: JAMF_PRO_URL, JAMF_PRO_USERNAME, JAMF_PRO_PASSWORD")
        sys.exit(1)
    
    jamf_url = jamf_url.rstrip('/')
    
    output_file = Path("terraform_imports.tf")
    summary_file = Path("import_summary.json")
    
    print(f"Connecting to Jamf Pro: {jamf_url}")
    
    searches = fetch_advanced_searches(jamf_url, jamf_username, jamf_password)
    
    if not searches:
        print("No advanced computer searches found")
        return
    
    print(f"\nFound {len(searches)} advanced computer searches")
    
    import_blocks = []
    for search in searches:
        search_id = search.get('id')
        search_name = search.get('name')
        
        if search_id and search_name:
            print(f"  - {search_name} (ID: {search_id})")
            import_block = generate_import_block(search_id, search_name)
            import_blocks.append(import_block)
        else:
            print(f"  - Skipping invalid search entry: {search}")
    
    if import_blocks:
        write_import_file(import_blocks, output_file)
        write_summary_json(searches, summary_file)
        
        print("\nNext steps:")
        print("1. Review the generated terraform_imports.tf file")
        print("2. Create corresponding resource blocks in your Terraform configuration")
        print("3. Run: terraform plan -generate-config-out=generated.tf")
        print("4. Review generated.tf and merge with your configuration")
        print("5. Run: terraform plan (Terraform will process the import blocks)")
        print("6. Run: terraform apply to complete the import")
    else:
        print("No valid searches to import")


if __name__ == "__main__":
    main()
