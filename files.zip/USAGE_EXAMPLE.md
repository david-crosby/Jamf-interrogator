# Complete Usage Example

## Project Structure

```
jamf-terraform-import/
├── .env                          # Your credentials (not in git)
├── .gitignore                    # Git ignore file
├── env.example                   # Template for .env
├── extract_advanced_searches.py  # Main extraction script
├── requirements.txt              # Python dependencies
├── run_extractor.sh             # Convenience wrapper script
├── README.md                     # Documentation
├── SDK_ADAPTER_GUIDE.md         # Guide for adding SDK support
├── terraform_imports.tf         # Generated import blocks
├── import_summary.json          # Generated summary
└── terraform/                    # Your Terraform configuration
    ├── main.tf
    ├── providers.tf
    └── variables.tf
```

## Step-by-Step Walkthrough

### 1. Initial Setup

```bash
# Clone or download the project files
cd jamf-terraform-import

# Create your .env file
cp env.example .env

# Edit .env with your credentials
nano .env
```

Your `.env` file should look like:

```bash
JAMF_PRO_URL=https://your-instance.jamfcloud.com
JAMF_PRO_USERNAME=your-api-user
JAMF_PRO_PASSWORD=your-api-password
```

### 2. Install Dependencies

```bash
# Using uv
uv pip install -r requirements.txt

# Or using pip
pip install -r requirements.txt
```

### 3. Run the Extractor

Option A - Using the wrapper script:
```bash
./run_extractor.sh
```

Option B - Direct Python execution:
```bash
source .env
python3 extract_advanced_searches.py
```

### 4. Review Generated Files

The script creates two files:

**terraform_imports.tf**
```hcl
# Terraform import blocks for Jamf Pro advanced computer searches
# Generated automatically - review before importing

import {
  to = jamfpro_advanced_computer_search.all_macs_with_filevault
  id = "1"
}

import {
  to = jamfpro_advanced_computer_search.computers_needing_updates
  id = "2"
}
```

**import_summary.json**
```json
{
  "total_searches": 2,
  "searches": [
    {
      "id": "1",
      "name": "All Macs with FileVault",
      "terraform_resource_name": "all_macs_with_filevault"
    },
    {
      "id": "2",
      "name": "Computers Needing Updates",
      "terraform_resource_name": "computers_needing_updates"
    }
  ]
}
```

### 5. Set Up Terraform Configuration

Create your Terraform provider configuration:

**terraform/providers.tf**
```hcl
terraform {
  required_providers {
    jamfpro = {
      source  = "deploymenttheory/jamfpro"
      version = "~> 0.19.0"
    }
  }
}

provider "jamfpro" {
  url      = var.jamf_url
  username = var.jamf_username
  password = var.jamf_password
}
```

**terraform/variables.tf**
```hcl
variable "jamf_url" {
  description = "Jamf Pro instance URL"
  type        = string
}

variable "jamf_username" {
  description = "Jamf Pro API username"
  type        = string
  sensitive   = true
}

variable "jamf_password" {
  description = "Jamf Pro API password"
  type        = string
  sensitive   = true
}
```

### 6. Copy Import Blocks

```bash
# Copy the generated import blocks to your Terraform directory
cp terraform_imports.tf terraform/
cd terraform
```

### 7. Generate Resource Configurations

Terraform 1.5+ can automatically generate resource configurations:

```bash
# Initialise Terraform
terraform init

# Generate resource configurations from imports
terraform plan -generate-config-out=generated_resources.tf

# Review the generated file
cat generated_resources.tf
```

### 8. Review and Customise

The generated `generated_resources.tf` will contain resource blocks like:

```hcl
resource "jamfpro_advanced_computer_search" "all_macs_with_filevault" {
  name = "All Macs with FileVault"
  # ... other attributes populated from your Jamf Pro instance
}
```

Review and customise these as needed, then merge them into your main configuration.

### 9. Import Resources

```bash
# Plan to verify everything looks correct
terraform plan

# Apply to import resources into state
terraform apply
```

### 10. Clean Up Import Blocks

Once imported successfully, you can remove the `terraform_imports.tf` file or move it to a backup location:

```bash
mv terraform_imports.tf ../terraform_imports.tf.backup
```

## Advanced: Using with CI/CD

### GitHub Actions Example

```yaml
name: Import Jamf Resources

on:
  workflow_dispatch:

jobs:
  import:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      
      - name: Install uv
        run: pip install uv
      
      - name: Install dependencies
        run: uv pip install -r requirements.txt
      
      - name: Run extractor
        env:
          JAMF_PRO_URL: ${{ secrets.JAMF_URL }}
          JAMF_PRO_USERNAME: ${{ secrets.JAMF_USERNAME }}
          JAMF_PRO_PASSWORD: ${{ secrets.JAMF_PASSWORD }}
        run: python3 extract_advanced_searches.py
      
      - name: Upload artifacts
        uses: actions/upload-artifact@v4
        with:
          name: terraform-imports
          path: |
            terraform_imports.tf
            import_summary.json
```

## Troubleshooting

### SDK Import Error

If you see:
```
Error: jamf-pro-sdk not installed
```

Solution:
```bash
uv pip install jamf-pro-sdk
```

### Authentication Error

If you see authentication errors, verify:
1. URL is correct and includes `https://`
2. URL doesn't have a trailing slash
3. Username and password are correct
4. API user has appropriate permissions

### No Searches Found

If the script reports zero searches:
1. Verify your Jamf Pro instance actually has advanced computer searches
2. Check API user has read permissions for advanced searches
3. Try accessing the API manually to confirm connectivity

### Invalid Resource Names

If Terraform complains about resource names:
- The script sanitises names, but very unusual characters might cause issues
- Check the `import_summary.json` to see how names were converted
- Manually adjust resource names in both the import blocks and resource definitions if needed

## Tips

1. **Incremental Imports**: For large numbers of searches, consider importing in batches
2. **Version Control**: Commit your Terraform configurations before importing
3. **Backup**: Always backup your Terraform state before major operations
4. **Testing**: Test the process in a non-production environment first
5. **Documentation**: Keep the `import_summary.json` as documentation of what was imported
