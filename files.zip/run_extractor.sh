#!/usr/bin/env zsh

set -e

echo "Jamf Pro Advanced Computer Search Terraform Importer"
echo "====================================================="
echo ""

if [ ! -f ".env" ]; then
    echo "Error: .env file not found"
    echo "Please create a .env file with your Jamf Pro credentials"
    echo "See env.example for the required format"
    exit 1
fi

source .env

if [ -z "$JAMF_PRO_URL" ] || [ -z "$JAMF_PRO_USERNAME" ] || [ -z "$JAMF_PRO_PASSWORD" ]; then
    echo "Error: Missing required environment variables"
    echo "Please ensure JAMF_PRO_URL, JAMF_PRO_USERNAME, and JAMF_PRO_PASSWORD are set in .env"
    exit 1
fi

if ! command -v python3 &> /dev/null; then
    echo "Error: python3 not found"
    exit 1
fi

echo "Checking dependencies..."
if ! python3 -c "import jamf_pro_sdk" 2>/dev/null; then
    echo "Installing required dependencies..."
    uv pip install -r requirements.txt
fi

echo ""
echo "Running extractor..."
echo ""

python3 extract_advanced_searches.py

if [ $? -eq 0 ]; then
    echo ""
    echo "Extraction complete!"
    if [ -f "terraform_imports.tf" ]; then
        echo ""
        echo "Generated files:"
        echo "  - terraform_imports.tf ($(wc -l < terraform_imports.tf) lines)"
        if [ -f "import_summary.json" ]; then
            echo "  - import_summary.json"
        fi
    fi
fi
