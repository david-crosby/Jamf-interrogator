# SDK Adapter Template
# This file shows how to add support for alternative Jamf Pro SDKs

## For thejoeker12/jamfpy-python-sdk-jamfpro

Once you can access the repository or have the SDK installed, you'll need to understand:

1. Import statement
```python
# Example - update with actual import
from jamfpy import Client  # or whatever the actual import is
```

2. Client initialisation
```python
# Example - update with actual method
client = Client(
    server=jamf_url,
    username=username,
    password=password
)
```

3. Fetching advanced computer searches
```python
# Example - update with actual method
searches = client.get_advanced_computer_searches()
# or
searches = client.advanced_computer_searches.list()
# or whatever the actual API method is
```

4. Response structure
```python
# The response might be:
# - A list of dicts: [{'id': 1, 'name': 'Search 1'}, ...]
# - A dict with a key: {'searches': [{'id': 1, 'name': 'Search 1'}, ...]}
# - Custom objects: [SearchObject(), ...]
```

## Adding to the script

Once you know the above, add this function to extract_advanced_searches.py:

```python
def fetch_advanced_searches_jamfpy(jamf_url, username, password):
    """Retrieve searches using thejoeker12/jamfpy SDK."""
    try:
        from jamfpy import Client  # Update with actual import
        
        client = Client(
            server=jamf_url,
            username=username,
            password=password
        )
        
        # Update with actual method call
        searches = client.get_advanced_computer_searches()
        
        # Normalise the response to a list of dicts
        # Update based on actual response structure
        if isinstance(searches, list):
            return searches
        elif isinstance(searches, dict) and 'searches' in searches:
            return searches['searches']
        
        return []
        
    except Exception as e:
        print(f"Error fetching with jamfpy: {e}")
        return None
```

Then update the SDK detection section:

```python
try:
    from jamfpy import Client
    SDK_AVAILABLE = 'jamfpy'
except ImportError:
    try:
        from jamf_pro_sdk import JamfProClient, BasicAuthProvider
        SDK_AVAILABLE = 'jamf_pro_sdk'
    except ImportError:
        SDK_AVAILABLE = None
```

And update the fetch_advanced_searches function:

```python
def fetch_advanced_searches(jamf_url, username, password):
    """Retrieve all advanced computer searches using available SDK."""
    
    if SDK_AVAILABLE == 'jamfpy':
        print("Using jamfpy SDK...")
        return fetch_advanced_searches_jamfpy(jamf_url, username, password)
    elif SDK_AVAILABLE == 'jamf_pro_sdk':
        print("Using jamf-pro-sdk...")
        return fetch_advanced_searches_jamf_pro_sdk(jamf_url, username, password)
    else:
        print("Error: No supported Jamf SDK found")
        sys.exit(1)
```
