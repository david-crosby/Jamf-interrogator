# Jamf Pro Advanced Computer Search Terraform Importer

Extract all advanced computer searches from a Jamf Pro tenant and generate Terraform import blocks for migration to infrastructure as code.

## Requirements

- Python 3.9 or higher
- uv package manager
- Jamf Pro credentials with read access to advanced computer searches
- Terraform 1.5 or higher (for using import blocks)
- One of the following Jamf Pro SDKs:
  - `jamf-pro-sdk` (official Mac Admins SDK) - currently supported
  - `jamfpy` (thejoeker12 SDK) - see SDK_ADAPTER_GUIDE.md for integration

## Installation

Install the required dependencies using uv:

```bash
uv pip install -r requirements.txt
```

Or if using a different SDK:

```bash
uv pip install jamfpy  # If using thejoeker12 SDK
```

For integrating alternative SDKs, refer to [SDK_ADAPTER_GUIDE.md](SDK_ADAPTER_GUIDE.md)

## Configuration

Set the following environment variables with your Jamf Pro credentials:

```bash
export JAMF_PRO_URL="https://your-instance.jamfcloud.com"
export JAMF_PRO_USERNAME="your-username"
export JAMF_PRO_PASSWORD="your-password"
```

For production use, consider storing credentials securely using a secrets manager or environment configuration file.

## Usage

Run the script to extract all advanced computer searches and generate import blocks:

```bash
python extract_advanced_searches.py
```

The script will:

1. Connect to your Jamf Pro instance
2. Retrieve all advanced computer searches
3. Generate Terraform import blocks for each search
4. Write the import blocks to `terraform_imports.tf`

## Output

The script generates a `terraform_imports.tf` file containing import blocks like:

```hcl
import {
  to = jamfpro_advanced_computer_search.all_macs_with_filevault
  id = "123"
}
```

## Terraform Workflow

After running the script:

1. Review the generated `terraform_imports.tf` file
2. Create corresponding resource blocks in your Terraform configuration or use Terraform to generate them:

```bash
terraform plan -generate-config-out=generated.tf
```

3. Import the resources into your Terraform state:

```bash
terraform plan
terraform apply
```

Terraform 1.5+ will automatically process the import blocks during plan/apply operations.

## Notes

- Resource names are sanitised by converting to lowercase and replacing spaces, hyphens, and dots with underscores
- The script uses the Jamf Pro Classic API for retrieving advanced computer searches
- Review all generated import blocks before importing to ensure they match your Terraform provider configuration

## Troubleshooting

### Authentication Errors

Ensure your credentials have appropriate permissions in Jamf Pro. The account needs read access to advanced computer searches.

### Import Block Errors

If Terraform reports errors during import, verify:

- The Jamf Pro provider is properly configured in your Terraform configuration
- The resource IDs match those in your Jamf Pro instance
- Your Terraform provider version supports advanced computer search resources

## Jamf Pro Provider

This script generates import blocks compatible with the Deployment Theory Jamf Pro Terraform provider:

https://registry.terraform.io/providers/deploymenttheory/jamfpro/latest

Ensure you have the provider configured in your Terraform configuration before importing resources.
