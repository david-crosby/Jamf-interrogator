#!/usr/bin/env bash
set -e

echo "Setting up Advanced Computer Search Extractor"
echo "=============================================="
echo

if ! command -v uv &> /dev/null; then
    echo "Error: uv is not installed"
    echo "Install uv: https://github.com/astral-sh/uv"
    exit 1
fi

echo "Creating virtual environment..."
uv venv

echo "Activating virtual environment..."
source .venv/bin/activate

echo "Installing dependencies..."
uv pip install -r requirements.txt

echo
echo "Setup complete!"
echo
echo "Next steps:"
echo "  1. Copy .env.example to .env and add your credentials"
echo "  2. Run: source .venv/bin/activate"
echo "  3. Run: python extract_advanced_searches.py"
