# Advanced Computer Search Extractor

Extract Advanced Computer Searches from Jamf Pro and generate Terraform import blocks for the Jamf Pro Terraform Provider.

## Prerequisites

- Python 3.8 or higher
- Access to a Jamf Pro tenant
- OAuth2 credentials (Client ID and Client Secret) with appropriate permissions

## Installation

Using `uv`:

```bash
uv venv
source .venv/bin/activate  # On macOS/Linux
uv pip install -r requirements.txt
```

## Configuration

Set the following environment variables:

```bash
export JAMF_URL="https://your-tenant.jamfcloud.com"
export JAMF_CLIENT_ID="your-client-id"
export JAMF_CLIENT_SECRET="your-client-secret"
```

Alternatively, create a `.env` file:

```bash
JAMF_URL=https://your-tenant.jamfcloud.com
JAMF_CLIENT_ID=your-client-id
JAMF_CLIENT_SECRET=your-client-secret
```

## Usage

Run the extraction script:

```bash
python extract_advanced_searches.py
```

The script will:

1. Connect to your Jamf Pro tenant using OAuth2 authentication
2. Retrieve all Advanced Computer Searches
3. Generate Terraform import blocks
4. Save the import blocks to `terraform_imports/advanced_computer_searches.tf`

## Output

The script generates Terraform import blocks in the following format:

```hcl
import {
  id = 123
  to = jamfpro_advanced_computer_search.jamfpro_advanced_computer_search_123
}
```

## Importing into Terraform

After running the extraction script:

```bash
cd terraform_imports
terraform init
terraform plan -generate-config-out=generated.tf
```

This will generate the corresponding Terraform resource configurations for your Advanced Computer Searches.

## Project Structure

```
.
├── extract_advanced_searches.py    # Main extraction script
├── importer/                        # Import library modules
│   ├── __init__.py
│   ├── importer.py
│   ├── resources.py
│   ├── models.py
│   ├── hcl.py
│   ├── enums.py
│   ├── dataclasses.py
│   ├── constants.py
│   ├── config_ingest.py
│   └── exceptions.py
├── jamfpy/                          # Jamf Pro SDK
└── terraform_imports/               # Generated import blocks (created by script)
```

## Troubleshooting

### Authentication Errors

Ensure your OAuth2 credentials have the following permissions:
- Read access to Advanced Computer Searches

### Connection Errors

Verify that:
- The JAMF_URL is correct and accessible
- Your network allows connections to Jamf Pro
- The OAuth2 credentials are valid and not expired

## Related Resources

- [Jamf Pro API Documentation](https://developer.jamf.com/jamf-pro/reference/findadvancedcomputersearches)
- [Jamf Pro Terraform Provider](https://registry.terraform.io/providers/deploymenttheory/jamfpro/latest)
- [jamfpy SDK](https://github.com/thejoeker12/jamfpy-python-sdk-jamfpro)
