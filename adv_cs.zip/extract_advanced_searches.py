#!/usr/bin/env python3
"""
Extract Advanced Computer Searches from Jamf Pro and generate Terraform import blocks.

This script connects to a Jamf Pro tenant, retrieves all Advanced Computer Searches,
and generates Terraform import blocks for use with the Jamf Pro Terraform Provider.
"""

import sys
import os
from pathlib import Path

import jamfpy
from importer import Importer, AdvancedComputerSearches


def get_credentials_from_env():
    """
    Retrieve Jamf Pro credentials from environment variables.
    
    Returns a dictionary containing the required authentication details,
    or exits if required variables are missing.
    """
    required_vars = {
        "JAMF_URL": os.getenv("JAMF_URL"),
        "JAMF_CLIENT_ID": os.getenv("JAMF_CLIENT_ID"),
        "JAMF_CLIENT_SECRET": os.getenv("JAMF_CLIENT_SECRET")
    }
    
    missing = [key for key, value in required_vars.items() if not value]
    
    if missing:
        print(f"Error: Missing required environment variables: {', '.join(missing)}")
        print("\nRequired environment variables:")
        print("  JAMF_URL - Your Jamf Pro URL (e.g., https://example.jamfcloud.com)")
        print("  JAMF_CLIENT_ID - OAuth client ID")
        print("  JAMF_CLIENT_SECRET - OAuth client secret")
        sys.exit(1)
    
    return required_vars


def create_jamf_client(credentials):
    """
    Create and return an authenticated Jamf Pro client.
    
    Uses OAuth2 authentication with the provided credentials.
    """
    return jamfpy.Tenant(
        fqdn=credentials["JAMF_URL"],
        auth_method="oauth2",
        client_id=credentials["JAMF_CLIENT_ID"],
        client_secret=credentials["JAMF_CLIENT_SECRET"]
    )


def write_import_blocks(output_path, import_blocks):
    """
    Write the generated import blocks to a file.
    
    Creates the output directory if it doesn't exist.
    """
    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    
    with output_file.open("w", encoding="utf-8") as f:
        f.write(import_blocks)
    
    return output_file


def main():
    """
    Main execution function.
    
    Orchestrates the extraction of Advanced Computer Searches and generation
    of Terraform import blocks.
    """
    print("Jamf Pro Advanced Computer Search Extractor")
    print("=" * 50)
    
    credentials = get_credentials_from_env()
    
    print(f"\nConnecting to: {credentials['JAMF_URL']}")
    
    try:
        client = create_jamf_client(credentials)
    except Exception as e:
        print(f"Error: Failed to authenticate with Jamf Pro: {e}")
        sys.exit(1)
    
    print("Successfully authenticated")
    
    searches_resource = AdvancedComputerSearches()
    
    print("Retrieving Advanced Computer Searches...")
    
    try:
        importer = Importer(
            client=client,
            targetted=[searches_resource]
        )
    except Exception as e:
        print(f"Error: Failed to retrieve searches: {e}")
        sys.exit(1)
    
    search_count = len(searches_resource.data)
    print(f"Found {search_count} Advanced Computer Search(es)")
    
    if search_count == 0:
        print("\nNo Advanced Computer Searches found. Nothing to export.")
        return
    
    print("\nGenerating Terraform import blocks...")
    import_blocks = importer.hcl_s()
    
    output_path = "terraform_imports/advanced_computer_searches.tf"
    output_file = write_import_blocks(output_path, import_blocks)
    
    print(f"\nImport blocks written to: {output_file.absolute()}")
    print(f"\nTo import into Terraform, run:")
    print(f"  cd {output_file.parent}")
    print(f"  terraform init")
    print(f"  terraform plan -generate-config-out=generated.tf")
    
    print("\nExtraction complete")


if __name__ == "__main__":
    main()
